<?php
	session_start(); // Start the session
	$db = new PDO('mysql:host=localhost;dbname=dbhar', 'root', '');

	// Connect to the database (replace dbname, username, and password with your own details)
	$email = $_POST['email'];
	$pass = $_POST['pass'];
	
	// Validate name and email
	if (empty($pass) || empty($email)) 
	{
		$_SESSION['error'] = "Please enter both a name and email.";
		echo $_SESSION['error'];
		header('Location: login.php'); // Redirect back to the login form
		exit();
	} 
	elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
	{
		$_SESSION['error'] = "Please enter a valid email address.";
		echo $_SESSION['error'];
		header('Location: login.php'); // Redirect back to the login form
		exit();
	} 
	else 	
	{
		// Check if the user exists in the database
		$stmt = $db->prepare('SELECT * FROM user WHERE email = :email AND pass = :pass');
		$stmt->execute(array(':email' => $email,':pass' => $pass));
		$user = $stmt->fetch();

		if($user) 
		{
			// User exists, store user data in session and redirect to welcome page
			$_SESSION['email'] = $user['email'];
			$_SESSION['pass'] = $user['pass'];
			header('Location: in2.php');
			exit();
		} 
		else 
		{
			// User not found, display error message and redirect back to login form
			$_SESSION['error'] = "Invalid login credentials.";
			header('Location: login.php');
			exit();
		}
	}
?>
