<?php

$servername= "localhost";
$username="root";
$password="";
$database="dbhar";

//create a connection 
$conn= mysqli_connect($servername,$username,$password,$database);
//die if connection was  ot successful
if(!$conn)
{
    die("Sorry we failed to connect: ". mysqli_connect_error());
}
else
{
    echo "connection successfull"; 
}


?>