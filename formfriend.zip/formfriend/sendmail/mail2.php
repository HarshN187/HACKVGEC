
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


$mail = new PHPMailer(true);

try {
    $conn=mysqli_connect("localhost","root","","dbhar");
    //$s="DELETE FROM ver";
    //$r=mysqli_query($conn,$s);
    $res = mysqli_query($conn, "SELECT description FROM note");
    $emails = array();
    while ($row = mysqli_fetch_assoc($res)) {
        $emails[] = $row['description'];
    }
    
   // $otp=rand(100000,999999);
   
    //$sql="INSERT INTO `ver` (`email`, `otp`, `conotp`) VALUES ('$em', $otp, '')";
    //$result=mysqli_query($conn,$sql);    


    $email = implode(",",$emails);
    $mail->isSMTP();                                           
    $mail->Host       = 'smtp.gmail.com';                     
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'goheluday6445@gmail.com';                    
    $mail->Password   = 'xkmnyxfashksauin';                             
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
    $mail->Port       = 465;                                    

    $pas="ABC@";
    $mail->setFrom('goheluday6445@gmail.com', 'VGEC');
  $i=0;
   while($emails[$i]!=NULL)
   {
    $em=$emails[$i];
    $mail->addAddress($em);             
    // $statement = $pdo->prepare('UPDATE user SET pass = :pass WHERE email = :email');
      //   $statement->execute(['pass' => $pas, 'email' => $email]);
 
     $mail->isHTML(true);                                 
     $mail->Subject = 'Information of your Account';
     
     $mail->Body    = $_POST['title']."<br>".$_POST['description'];
     $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
   
     $mail->send();
     $i=$i+1;
    
   }
      
    
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>


    