<?php

// Include the autoloader
require 'C:\xampp\htdocs\phptut\vendor\autoload.php';
//require 'C:\xampp\htdocs\phptut\PhpSpreadsheet-1.28.0\PhpSpreadsheet-1.28.0\src\PhpSpreadsheet';
// Load the spreadsheet file
$spreadsheet = \src\PhpSpreadsheet\IOFactory::load('C:\Users\91915\Downloads\INFO.xlsx');

// Select the worksheet
$worksheet = $spreadsheet->getActiveSheet();

// Get the highest row and column numbers
$highestRow = $worksheet->getHighestRow();
$highestColumn = $worksheet->getHighestColumn();

// Loop through each row of the worksheet
for ($row = 1; $row <= $highestRow; $row++) {
    // Loop through each column of the row
    for ($col = 'A'; $col <= $highestColumn; $col++) {
        // Get the cell value
        $cellValue = $worksheet->getCell($col.$row)->getValue();
        // Do something with the cell value, like print it
        echo $cellValue . "\t";
    }
    // End the row
    echo "\n";
}


?>