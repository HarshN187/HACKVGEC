
<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


$mail = new PHPMailer(true);

try {
    $conn=mysqli_connect("localhost","root","","dbhar");
    $s="DELETE FROM ver";
    $r=mysqli_query($conn,$s);
    $em=$_POST['email'];
    $otp=rand(100000,999999);
   
    $sql="INSERT INTO `ver` (`email`, `otp`, `conotp`) VALUES ('$em', $otp, '')";
    $result=mysqli_query($conn,$sql);    

    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $mail->isSMTP();                                           
    $mail->Host       = 'smtp.gmail.com';                     
    $mail->SMTPAuth   = true;                                   
    $mail->Username   = 'goheluday6445@gmail.com';                    
    $mail->Password   = 'xkmnyxfashksauin';                             
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
    $mail->Port       = 465;                                    

    $pas="ABC@".$otp;
    $mail->setFrom('goheluday6445@gmail.com', 'Reset Password');

    $mail->addAddress($em);             
    $statement = $pdo->prepare('UPDATE user SET pass = :pass WHERE email = :email');
        $statement->execute(['pass' => $pas, 'email' => $email]);

    $mail->isHTML(true);                                 
    $mail->Subject = 'Information of your Account';
    $mail->Body    = 'Your new password is: '.$pas;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    //$statement ='UPDATE user SET pass = :$otp WHERE email = :email';
    //$resul=mysqli_query($statement,$conn);
    $mail->send();
    header("location:login.php");
    
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>


    