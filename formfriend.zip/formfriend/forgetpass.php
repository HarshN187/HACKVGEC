<?php

// Assume the user has submitted the form with their email address
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize the email address

    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    // Check if the email address exists in the database
    // (Replace database_host, database_name, database_user, database_password with your actual values)
    $pdo = new PDO('mysql:host=localhost;dbname=dbhar', 'root', '');
   
    $statement = $pdo->prepare("SELECT * FROM user WHERE email = :email");
    $statement->execute(['email' => $email]);
    $user = $statement->fetch();
   
    if (!$user) {
       
        // The email address does not exist in the database
        // echo "This email address does not exist in our system.";
        $error = "This email address does not exist in our system.";
        header("location:forgetpass.php");
        
    } 
    else {
        try{
       require 'C:\xampp\htdocs\sendmail\mail.php';
        $conn=mysqli_connect("localhost","root","","dbhar");
        $s="DELETE FROM ver";
        $r=mysqli_query($conn,$s);
        $em=$_POST['email'];
        $otp=rand(100000,999999);
       
        $sql="INSERT INTO `ver` (`email`, `otp`, `conotp`) VALUES ('$em', $otp, '')";
        $result=mysqli_query($conn,$sql);    
    
        $mail->isSMTP();                                           
        $mail->Host       = 'smtp.gmail.com';                     
        $mail->SMTPAuth   = true;                                   
        $mail->Username   = 'goheluday6445@gmail.com';                    
        $mail->Password   = 'xkmnyxfashksauin';                             
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            
        $mail->Port       = 465;                                    
    
      
        $mail->setFrom('goheluday6445@gmail.com', 'Gujrat Police');
    
        $mail->addAddress($em);             
        $statement = "UPDATE user SET pass = :pass WHERE email = :email";
        $res=mysqli_query($statement,$conn);

    
        $mail->isHTML(true);                                 
        $mail->Subject = 'Information of your Account';
        $mail->Body    = 'Your new password is '.$otp;
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
        //$statement = 'UPDATE user SET pass = :$otp WHERE email = :email';
        //$resul= mysqli_query($staement,$conn);
        $mail->send();
        header("location:login.php");
        
    } 
    catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
    }
}
?>

<!-- <!DOCTYPE html>
<html>
<head>
    <title>Forget Password</title>
</head>
<body>
    <h1>Forget Password</h1>
  <?php //if (isset($error)): ?>
        <p style="color: red;"><?php //echo "khoto email"; ?></p>
    <?php //endif; ?>
    <?php //if (isset($success)): ?>
        <p style="color: green;"><?php// echo $success; ?></p>
    <?php //endif; ?>
    <form method="post" action="forgetpass.php">
        <label for="email">Email Address:</label>
        <input type="email" name="email" required>
        <br>
        <input type="submit" value="Reset Password">
    </form>
</body>
</html> -->
<!-- <!DOCTYPE html> 
<html>
<head>
    <title>Forget Password</title>
</head>
<body>
    <h1>Forget Password</h1>
    <form method="POST" action="forgetpass.php">
        <label for="email">Email Address:</label>
        <input type="email" id="email" name="email" required>
        <br>
        <input type="submit" value="Reset Password">
    </form>
</body>
</html> -->


<!DOCTYPE html>
<html lang="en">

<head>


    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>

        
  <script defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/js/all.min.js"></script>
    <!-- <link rel="stylesheet" href="C:\Users\91812\web_devlopment\new\css\style.css"> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Merriweather&family=Montserrat:wght@100;400&family=Poppins:wght@300&family=Sacramento&family=Sono:wght@300;700;800&display=swap"
        rel="stylesheet">
    <style>
        .navbar {
            background-color: #C9EEFF;
            color: black;
            margin-top: 4%;
        }

        .navbar-brand {
            line-height: 2;
            font-family: "Poppins";
            font-weight: bolder;
            font-size: 1.5vw;
        }

        .logo-img {
            height: 17%;
            width: 17%;
            text-align: center;
            float: left;
            margin-right: 0.9rem;
        }

        .nav-container {
            margin: auto;
        }

        .card-title{
            font-family: "Poppins";
            font-weight: 800;
        }
        body {
  background: #C9EEFF;
  /* background: linear-gradient(to right, #C9EEFF, #33AEFF); */
}

.btn-login {
  font-size: 0.9rem;
  letter-spacing: 0.05rem;
  padding: 0.75rem 1rem;
  margin-top: 10%;
}

.form-floating{
        margin-top: 10%;
        font-weight: 500;
        /* margin-bottom: 10%; */
}

.form-check{
    margin-top: 10%;
    margin-bottom: 10%;
}

.card-body{
     /* border-radius: 20%;  */
    background: white;
    border-radius: 30px;
    opacity: 1;
    
}

.underline{
    border-bottom: 3px solid #1c5bd9;
  padding-bottom: 1.5px;
  
}

.card{
    background-color: #C9EEFF;
    
}

    </style>

    <title>Document</title>

</head>

<body>
    <div class="row">
        <nav class="navbar navbar-expand-md">
            <div class="container-fluid">
                <div class="nav-container">
                    <img class="logo-img"src="C:\Users\91812\web_devlopment\new\vgeclogo.png" alt="">
                    <a class="navbar-brand" href="#">Vishwakarma Government Engineering College<br>
                        Chandkheda, Ahmedabad.</a>
                </div>
            </div>
        </nav>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                <div class="card border-0  my-5">
                    <div class="card-body p-4 p-sm-5">
                        <h5 class="card-title text-center mb-5 fw-light fs-5"><span class="underline">Reset Password</span></h5>
                        <form method="POST" action="forgetpass.php">
                            <!-- <label for="email">Email Address:</label>
                            <input type="email" id="email" name="email" required>
                            <br> -->

                            <div class="form-floating mb-3">
                                
                                <input type="email" class="form-control" id="floatingInput"
                                    placeholder="name@example.com">
                                <label for="floatingInput">Email address</label>
                            
                            </div>

                            <!-- <input type="submit" value="Reset Password"> -->
                            <div class="d-grid">
                                <button class="btn btn-primary btn-login text-uppercase fw-bold" type="submit" value="Reset Password">Sign
                                    in</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html>

