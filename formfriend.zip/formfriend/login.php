<!-- <!DOCTYPE html>
<html>
<head>
	<title>Login System</title>
</head>
<body>
	<form action="welcome.php" method="POST">
		<label for="name">Name:</label>
		<input type="text" id="name" name="name" required><br>

		<label for="email">Email:</label>
		<input type="email" id="email" name="email" required><br>

		<input type="submit" value="Login">
	</form>
</body>
</html> -->
<!DOCTYPE html>
<html lang="en">

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"     integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN"
        crossorigin="anonymous"></script>

        
  <script defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/js/all.min.js"></script>
    <link rel="stylesheet" href="C:\Users\91812\web_devlopment\new\css\style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Merriweather&family=Montserrat:wght@100;400&family=Poppins:wght@300&family=Sacramento&family=Sono:wght@300;700;800&display=swap"
        rel="stylesheet">
    <style>
        .navbar {
            background-color: #C9EEFF;
            color: black;
            margin-top: 4%;
        }

        .navbar-brand {
            line-height: 2;
            font-family: "Poppins";
            font-weight: bolder;
            font-size: 1.5vw;
        }

        .logo-img {
            height: 17%;
            width: 17%;
            text-align: center;
            float: left;
            margin-right: 0.9rem;
        }

        .nav-container {
            margin: auto;
        }

        .card-title{
            font-family: "Poppins";
            font-weight: bolder;
        }
        body {
            background : #C9EEFF; 
  /* background: linear-gradient(to right, #C9EEFF, #33AEFF); */
            }

.btn-login {
  font-size: 0.9rem;
  letter-spacing: 0.05rem;
  padding: 0.75rem 1rem;	
}

.form-floating{
        margin-top: 10%;
}

.form-check{
    margin-top: 10%;
    margin-bottom: 10%;
}

.card-body{
     /* border-radius: 20%;  */
    background: white; 
    border-radius: 30px;
}

.card{
    background-color: #C9EEFF;
}

.forgot{
    margin-top: 4%;
    margin-bottom:7%;
}

    </style>

    <title>Document</title>

</head>

<body>
    <div class="row">
        <nav class="navbar navbar-expand-md">
            <div class="container-fluid">
                <div class="nav-container">
                    <img class="logo-img" src="vgeclogo.png" alt="">
                    <p class="navbar-brand" >Vishwakarma Government Engineering College<br>
                        Chandkheda, Ahmedabad.</p>
                </div>
            </div>
        </nav>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-sm-9 col-md-7 col-lg-5 mx-auto">
                <div class="card border-0  my-5">
                    <div class="card-body p-4 p-sm-5">
                        <h5 class="card-title text-center mb-5 fw-light fs-5">Admin Login</h5>
                        <form action="welcome.php" method="POST">
                            <div class="form-floating mb-3">
                                
                                <input type="email" class="form-control" id="email" name="email"
                                    placeholder="name@example.com">
                                <label for="floatingInput">Email address</label>
                            
                            </div>
                            <div class="form-floating mb-3">
                                <input type="password" class="form-control" id="pass" name="pass"
                                    placeholder="Password">
                                <label for="floatingPassword">Password</label>
                            </div>
                            
				
                            <!-- <div class="form-check mb-3">
                                <input class="form-check-input" type="checkbox" value="" id="rememberPasswordCheck">
                                <label class="form-check-label" for="rememberPasswordCheck">
                                    Remember password
                                </label>
                            </div> -->

                            <div class="forgot">
                                <a href="forget.php">Forgot Password ?</a>
                            </div>
                            <div class="d-grid">
                             <button class="btn btn-primary btn-login text-uppercase fw-bold" type="submit">Log
                                    in</button>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

</body>

</html> 